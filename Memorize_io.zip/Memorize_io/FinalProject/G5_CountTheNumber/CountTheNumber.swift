//
//  game.swift
//  game2
//
//  Created by WUIJUI on 2021/6/20.
//

import Foundation

class CountTheNumber {
    public var ret=[Bool]()
    public var level:Int
    public var answer:Int
    public var num:Int
    func isAnswer(ans:Int) -> Bool {
        if ans == answer{
            return true
        }
        return false
    }
    func random(){
        
        for _ in 0...answer{
            ret.append(true)
        }
        for _ in answer...num-1{
            ret.append(false)
        }
        ret.shuffle()
    }
    init(level:Int) {
        self.level = level
        self.num = 2*level + 6
        self.answer = Int.random(in: 3...2*level+3)
        random()
    }
}
