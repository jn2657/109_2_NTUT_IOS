//
//  Card.swift
//  LAB04-MatchingGmae
//
//  Created by 上官 on 2021/3/29.
//

import Foundation

struct Card_Match: Hashable {
    var hashValue: Int{
        return identifier
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(identifier)
    }
    
    static func ==(lhs: Card_Match, rhs: Card_Match) -> Bool{
        return lhs.identifier == rhs.identifier
    }
    
    var isFaceup = false
    var isMatched = false
    private var identifier:Int //use ID instead of emoji
    
    static var identifierFactory = 0
    
    static func getUniqueIdentifier()->Int{
        identifierFactory += 1
        return identifierFactory
    }
    
    init(){
        self.identifier = Card_Match.getUniqueIdentifier()
    }
    
}
