//
//  LV1.swift
//  game
//
//  Created by WUIJUI on 2021/6/6.
//

import UIKit

class LV5: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "back")!)
        point.text = "目前得分：\(globalpoint)"
        //ballsinit()
        // Do any additional setup after loading the view.
    }
    var HasStart = false
    var xLoc = [1,2,3,4,5,6]
    var yLoc = [3,4,5,6,7,8,9,10,11]
    var choosed = 0
    @IBAction func Start(_ sender: Any) {
        if !HasStart {
            HasStart=true
            StartButton.setTitle("", for: UIControl.State.normal)
            
            StartButton.alpha = 0
            StartButton.center = CGPoint(x:0,y:0)
            move()
        }
        
    }
    @IBOutlet weak var StartButton: UIButton!
    @IBOutlet var Balls: [UIButton]!
    
    var Game = TrackingBalls(level: 5)
    func GoBack(alert:UIAlertAction) {
        performSegue(withIdentifier: "back", sender: UIAlertAction.self)
    }
    func NextLevel(alert:UIAlertAction) {
        performSegue(withIdentifier: "next", sender: UIAlertAction.self)
    }
    @IBAction func Ball(_ sender: Any) {
        if HasStart {
            if let index = Balls.firstIndex(of: sender as! UIButton){
                    
                let A = Game.choose(at: index)
                if A == true {
                    Balls[index].tintColor = .green
                    choosed += 1
                    if choosed == 5 {
                        globalpoint += 50
                        let controller = UIAlertController(title: "答對!", message: "加五十分", preferredStyle: .alert)
                           let okAction = UIAlertAction(title: "下一關", style: .default, handler: NextLevel)
                           controller.addAction(okAction)
                           present(controller, animated: true, completion: nil)
                    }
                    
                }
                else{
                    Balls[index].tintColor = .red
                    let controller = UIAlertController(title: "錯誤!", message: "你一共獲得\(globalpoint)分", preferredStyle: .alert)
                       let okAction = UIAlertAction(title: "回到首頁", style: .default, handler: GoBack)
                       controller.addAction(okAction)
                       present(controller, animated: true, completion: nil)
                }
            }
        }
        else{
            let controller = UIAlertController(title: "請按start開始遊戲!", message: "點擊ＯＫ繼續", preferredStyle: .alert)
               let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
               controller.addAction(okAction)
               present(controller, animated: true, completion: nil)
        }
    }
    func ballsinit(){
        for index in 0...Balls.count - 1 {
            Balls[index].frame = CGRect(x: randx(), y:randy(), width: 50, height: 50)
            Balls[index].setTitle("", for: UIControl.State.normal)
            Balls[index].tintColor = UIColor.orange
        }
    }

    
    func randx() -> Int {
        let randindex = Int.random(in: 0...xLoc.count - 1)
        let ans = xLoc[randindex]
        xLoc.remove(at: randindex)
        if xLoc.count <= 0 {
            xLoc = [1,2,3,4,5,6]
        }
        return ans*50
    }
    func randy() -> Int {
        let randindex = Int.random(in: 0...yLoc.count - 1)
        let ans = yLoc[randindex]
        yLoc.remove(at: randindex)
        if yLoc.count <= 0 {
            yLoc = [3,4,5,6,7,8,9,10,11,12,13,14,15]
        }
        return ans*50
    }
    
    @IBOutlet weak var point: UILabel!
    
    func move(){
        var answer = [Int]()
        

        for index in 0...self.Balls.count - 1{
            if self.Game.choose(at: index) == true {
                answer.append(index)
            }
        }
        for item in answer {
            UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 0, animations: {
                self.Balls[item].tintColor = UIColor.green
            }, completion: nil)
            
            UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 1, animations: {
                self.Balls[item].tintColor = UIColor.orange
            }, completion: nil)
        }
        
        
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 2, delay: 4, animations: {
            for index in 0...self.Balls.count - 1{
                self.Balls[index].frame = CGRect(x: self.randx(), y:self.randy(), width: 50, height: 50)
            }
        }, completion: nil)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
}

