//
//  G2.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/16.
//

import Foundation
import SwiftUI

struct G2: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> ViewController_G2 {
            UIStoryboard(name: "G2", bundle: nil).instantiateViewController(identifier: "ViewController_G2") as! ViewController_G2
        }
        
    func updateUIViewController(_ uiViewController: ViewController_G2, context: Context) {
    }
    typealias UIViewType = ViewController_G2
}

struct G2_Previews: PreviewProvider {
    static var previews: some View {
        G2().preferredColorScheme(.dark)
    }
}
