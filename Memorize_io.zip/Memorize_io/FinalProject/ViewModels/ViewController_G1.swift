//
//  ViewController.swift
//  memorize2.io
//
//  Created by 李昆哲 on 2021/5/6.
//

import UIKit

class ViewController_G1: UIViewController {
    var timeLeft = 2
    var initialLevel = 4
    var correctTouch = 0
    var Score = 0
    var lastScore = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Card.resetHashValue()
        for index in self.G1_cardList.indices{
            let button = self.G1_cardList[index]
            button.backgroundColor = .clear
            button.layer.borderWidth = 5
            button.layer.borderColor = UIColor.gray.cgColor
        }
        initialLevel = 4
        correctTouch = 0
        Score = 0
        lastScore = 0
        game.reset(level: initialLevel)
    }
    
    
    lazy var game:OneSecondMemory = OneSecondMemory(totalCards: G1_cardList.count)
    @IBOutlet var G1_cardList: [UIButton]!
    
    @IBAction func touchCard(_ sender: UIButton){
        if let cardNumber = G1_cardList.firstIndex(of: sender){
            if(!game.chooseCard(at: cardNumber)){
                showRestartAlert()
            }
            updateViewFromModel()
        }
    }
    
    func updateViewFromModel(){
        for index in G1_cardList.indices{
            let button = G1_cardList[index]
            let card = game.cards[index]
            if(card.isTouched){
                if(card.isActivate && !card.stopWork){
                    game.cards[index].stopWork = true
                    button.backgroundColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)
                    correctTouch += 1
                    Score += 30
                    self.score.text = "目前分數: \(String(self.lastScore+self.Score))"
                    if(correctTouch == initialLevel){
                        showNextLevelAlert()
                    }
                }else if(!card.isActivate){
                    button.setTitle("❌", for: UIControl.State.normal)
                }
            }
        }
    }
    
    func showCardsForOneSecond(){
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            for index in self.G1_cardList.indices{
                let button = self.G1_cardList[index]
                let card = self.game.cards[index]
                if(card.isActivate){
                    button.backgroundColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)
                }
            }
            self.timeLeft -= 1
            if(self.timeLeft==0){
                timer.invalidate()
                for index in self.G1_cardList.indices{
                    let button = self.G1_cardList[index]
                    button.backgroundColor = .clear
                }
                self.timeLeft = 2
            }
        }
    }
    
    func showRestartAlert(){
        let controller = UIAlertController(title: "錯誤！", message: "是否重新挑戰 ?", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "重來", style: .default) { (_) in
            self.Score = 0
            self.start((Any).self)
        }
        controller.addAction(okAction)
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        controller.addAction(cancelAction)
        present(controller, animated: true, completion: nil)
    }
    
    func showNextLevelAlert(){
        let controller = UIAlertController(title: "成功！", message: "繼續下一關 ?", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "繼續", style: .default) { (_) in
            self.initialLevel += 1
            self.lastScore += self.Score
            self.Score = 0
            self.level.text = "Level: \(self.initialLevel-3)"
            self.score.text = "目前分數: \(String(self.lastScore))"
            self.start((Any).self)
        }
        controller.addAction(okAction)
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        controller.addAction(cancelAction)
        present(controller, animated: true, completion: nil)
    }

    @IBAction func start(_ sender: Any) {
        correctTouch = 0
        for i in G1_cardList.indices{
            let button = G1_cardList[i]
            button.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            button.setTitle("", for: UIControl.State.normal)
        }
        game.reset(level: initialLevel)
        showCardsForOneSecond()
    }
    
    @IBOutlet weak var level: UILabel!
    @IBOutlet weak var score: UILabel!
}

