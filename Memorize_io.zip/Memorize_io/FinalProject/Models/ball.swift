//
//  ball.swift
//  game
//
//  Created by WUIJUI on 2021/6/6.
//

import UIKit
struct ball {
    public var isAnswer:Bool
    init() {
        isAnswer = false
    }
}
