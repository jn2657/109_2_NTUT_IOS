//
//  About.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import SwiftUI

struct About: View {
    var body: some View {
        VStack{
            Text("Memorize.io")
                .font(.custom("Bradley Hand", size: 50))
                .foregroundColor(.blue)
                .padding()
            
            Text("這是一個考驗記憶力的小遊戲合輯，共有6種不同的小遊戲可玩．其中包含了雙人的小遊戲，可以和朋友一起挑戰．同時還有分數和排名，可供參考．")
                .font(.custom("Bradley Hand", size: 30))
                .padding()
            
            Text("HAVE FUN！")
                .font(.custom("Bradley Hand", size: 50))
                .foregroundColor(.yellow)
                .padding()
        }
    }
}

struct About_Previews: PreviewProvider {
    static var previews: some View {
        About()
    }
}
