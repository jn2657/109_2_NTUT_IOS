//
//  AccountInfoView.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import SwiftUI
import URLImage

struct AccountInfoView: View{
    @Binding var account: Account
    
    var body: some View{
        VStack{
            HStack{
                URLImage(account.Image) {
                    // This view is displayed before download starts
                    EmptyView()
                } inProgress: { progress in
                    // Display progress
                    Text("Loading...")
                } failure: { error, retry in
                    // Display error and retry button
                    VStack {
                        Text(error.localizedDescription)
                        Button("Retry", action: retry)
                    }
                } content: { image in
                    // Downloaded image
                    image
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40, height: 40)
                }
                Text(account.Name)
                    .font(.title2)
                    .foregroundColor(.white)
            }
            Text(account.Email)
                .font(.title2)
                .foregroundColor(.white)
        }
    }
}

struct AccountWithoutLogin: View{
    var body: some View{
        Text("請先登入")
    }
}

struct AccountInfoViewContainer: View{
    @State var account = Account(Name: "NameTest", Image: AssetsExtractor.createLocalUrl(forImageNamed: "outline_account_circle_white_36pt")!, Email: "email.email", State: false, Content: "Log In")
    
    var body: some View{
        AccountInfoView(account: $account)
    }
}

struct AccountInfoView_Previews: PreviewProvider {
    static var previews: some View {
        AccountInfoViewContainer()
    }
}
