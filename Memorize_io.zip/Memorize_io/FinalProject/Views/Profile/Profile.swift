//
//  Profile.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import SwiftUI
import FacebookLogin
import AVFoundation

struct Profile_View: View {
    @State private var LoginContent: String = "Log In"
    @State private var showLoginView = false
    @Binding var account: Account
    @Binding var music: Music
    @State var index: ProfileContent = ProfileContent.accountInfo
    
    let ProfileList = [ProfileRows(Icon: "outline_people_white_36pt", Title: "Account Info", ProfileIndex: ProfileContent.accountInfo),
                       ProfileRows(Icon: "outline_settings_white_36pt", Title: "Setting", ProfileIndex: ProfileContent.setting),
                       ProfileRows(Icon: "outline_error_white_36pt", Title: "About", ProfileIndex: ProfileContent.about),
                       ProfileRows(Icon: "outline_email_white_36pt", Title: "Contact Us", ProfileIndex: ProfileContent.contactUs)]
    
    var body: some View {
        ZStack{
            Color.black
            VStack{
                List(ProfileList, id: \.Title){ (rows) in
                    ZStack {
                        Button(action: {
                            index = rows.ProfileIndex
                            }, label: {
                                
                            })
                        NavigationLink(
                            destination: ProfileContentView(profileIndex: $index, account: $account, music: $music),
                            label: {
                                HStack{
                                    Image(rows.Icon)
                                    Text(rows.Title)
                                        .foregroundColor(.white)
                                }

                        })
                    }
                }
                Spacer()
                Button(action: {
                    if(account.Content == "Log Out"){
                        let manager = LoginManager()
                        manager.logOut()
                        account.Content = "Log In"
                    }else{
                        showLoginView = true
                    }
                }){
                    Text("\(account.Content)")
                        .font(.title2)
                        .foregroundColor(.white)
                }
                .sheet(isPresented: $showLoginView) {
                    LoginView(account: $account)
                }
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding()
                .background(Color.gray)
                .padding(.bottom, 400)
                .padding(.horizontal, 25)
            }
        }
        .toolbar(content: {
            ToolbarItem(placement: .principal) {
                VStack{
                    Text("Profile")
                        .font(.custom("Chalkduster", size: 52))
                        .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
                }
            }
        })
    }
}

struct ProfileRows {
    let Icon:String
    let Title:String
    let ProfileIndex:ProfileContent
}

struct Profile_ViewContainer: View {
    @State var accountName: String = "name"
    @State var accountImage: URL = AssetsExtractor.createLocalUrl(forImageNamed: "user")!
    @State var accountEmail: String = "email.com"
    @State var loginState: Bool = false
    @State var account: Account = Account(Name: "NameTest", Image: AssetsExtractor.createLocalUrl(forImageNamed: "outline_account_circle_white_36pt")!, Email: "email.com", State: false, Content: "Log In")
    @State var index: ProfileContent = ProfileContent.accountInfo
    @State var musicPlayer = Music(music: AVQueuePlayer(), isPlaying: false, volume: Float(1))
    
    var body: some View{
        Profile_View(account: $account, music: $musicPlayer)
    }
    
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            Profile_ViewContainer()
        }
    }
}
