//
//  RankRow.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/17.
//

import SwiftUI

struct RankRow: View {
    let player: Rank
    var body: some View {
        HStack {
            Image(systemName: "rosette")
                .foregroundColor(Color.yellow)
                .font(.custom("Bradley Hand", size: 30))
                .padding()
            Text(player.name)
                .foregroundColor(.white)
                .font(.custom("Bradley Hand", size: 30))
                .padding()
            Spacer()
            Text(String(player.score))
                .foregroundColor(.white)
                .font(.custom("Bradley Hand", size: 30))
                .padding()
        }
        .background(Color.black)
        .edgesIgnoringSafeArea(.all)
        Spacer()
    }
}
struct RankRow_Previews: PreviewProvider {
    static var previews: some View {
        RankRow(player: Rank(name: "A", score: 2000))
    }
}
