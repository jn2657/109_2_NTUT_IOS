//
//  G5.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import Foundation
import SwiftUI

struct G5: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> ViewController_G5 {
            UIStoryboard(name: "G5", bundle: nil).instantiateViewController(identifier: "ViewController_G5") as! ViewController_G5
        }
        
    func updateUIViewController(_ uiViewController: ViewController_G5, context: Context) {
    }
    typealias UIViewType = ViewController_G5
}

struct G5_Previews: PreviewProvider {
    static var previews: some View {
        G5().preferredColorScheme(.dark)
    }
}
