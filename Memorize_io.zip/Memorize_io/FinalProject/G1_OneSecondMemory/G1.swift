//
//  G1.swift
//  memorize2.io
//
//  Created by 李昆哲 on 2021/5/14.
//

import Foundation
import SwiftUI

struct G1: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> ViewController_G1 {
            UIStoryboard(name: "G1", bundle: nil).instantiateViewController(identifier: "ViewController_G1") as! ViewController_G1
        }
        
    func updateUIViewController(_ uiViewController: ViewController_G1, context: Context) {
    }
    typealias UIViewType = ViewController_G1
}

struct G1_Previews: PreviewProvider {
    static var previews: some View {
        G1().preferredColorScheme(.dark)
    }
}
