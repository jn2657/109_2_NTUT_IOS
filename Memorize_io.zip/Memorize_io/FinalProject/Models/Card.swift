//
//  Card.swift
//  memorize2.io
//
//  Created by 李昆哲 on 2021/5/13.
//

import Foundation

struct Card: Hashable {
    var hashValue: Int{
        return identifier
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(identifier)
    }
    
    var isActivate = false
    var isTouched = false
    var stopWork = false
    private var identifier:Int
    static var identifierFactory = 0
    
    static func getUniqueIdentifier()->Int{
        identifierFactory += 1
        return identifierFactory
    }
    
    static func resetHashValue(){
        identifierFactory = 0
    }
    
    init() {
        self.identifier = Card.getUniqueIdentifier()
    }
}
