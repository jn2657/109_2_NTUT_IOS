//
//  LV1.swift
//  game2
//
//  Created by WUIJUI on 2021/6/20.
//

import UIKit
class G5_LV2: UIViewController {
    var Game = CountTheNumber(level: 2)
    override func viewDidLoad() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "back")!)
        super.viewDidLoad()
        for index in 0...bunny.count-1 {
            bunny[index].frame = CGRect(x: -100, y: 650, width: 78, height: 136)
        }
        GuessLable.alpha = 0
        guesstext.alpha = 0
        sublable.alpha = 0
        points.text = "point:\(globalpoint)"
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var startbutton: UIButton!
    @IBOutlet var bunny: [UIImageView]!
    
    
    @IBAction func start(_ sender: Any) {
        startbutton.setTitle("", for: UIControl.State.normal)
        startbutton.alpha = 0
        startbutton.center = CGPoint(x:0,y:0)
        Move()
        GuessLable.alpha = 1
        guesstext.alpha = 1
        sublable.alpha = 1
    }
    @IBOutlet weak var ans: UILabel!
    @IBOutlet weak var points: UILabel!
    @IBOutlet weak var GuessLable: UILabel!
    @IBOutlet weak var guesstext: UITextField!
    @IBOutlet weak var sublable: UIButton!
    func NextLevel(alert:UIAlertAction) {
        performSegue(withIdentifier: "next", sender: UIAlertAction.self)
    }
    func GoBack(alert:UIAlertAction) {
        performSegue(withIdentifier: "back", sender: UIAlertAction.self)
    }
    @IBAction func submit(_ sender: Any) {
        if guesstext.text == String(Game.answer) {
            globalpoint += 100
            let controller = UIAlertController(title: "答對!", message: "加一百分", preferredStyle: .alert)
               let okAction = UIAlertAction(title: "下一關", style: .default, handler: NextLevel)
               controller.addAction(okAction)
               present(controller, animated: true, completion: nil)
        }
        else{
            
            let controller = UIAlertController(title: "錯誤!", message: "你一共獲得\(globalpoint)分",  preferredStyle: .alert)
               let okAction = UIAlertAction(title: "回到首頁", style: .default, handler: GoBack)
            controller.addAction(okAction)
               present(controller, animated: true, completion: nil)
        }
    }
    func Move()  {
        let answer = Game.answer
        ans.text = "ANS:\(answer)"
        var D:Int

        for index in 0...Game.num-1{
            if Game.ret[index]{
                D = 2
            }else{
                D = 4
            }
            UIViewPropertyAnimator.runningPropertyAnimator(withDuration: TimeInterval(D), delay: TimeInterval(index), animations: {
                if(self.Game.ret[index]){
                    self.bunny[index].frame = CGRect(x: 150, y:650, width: 78, height: 136)
                }else{
                    self.bunny[index].frame = CGRect(x: 500, y:650, width: 78, height: 136)
                }
                
            }, completion:nil)
        }
        
    }
    
}
