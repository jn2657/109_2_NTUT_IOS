//
//  ProfileContentView.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import SwiftUI
import AVFoundation

enum ProfileContent{
    case accountInfo, setting, about, contactUs, login
}

struct ProfileContentView: View {
    @Binding var profileIndex: ProfileContent
    @Binding var account: Account
    @Binding var music: Music
    @State var volume = Float(0.3)
    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                if profileIndex == .accountInfo {
                    AccountInfoView(account: $account)
                }else if profileIndex == .setting {
                    Setting(volume: $volume)
                }else if profileIndex == .about {
                    About()
                }else if profileIndex == .contactUs {
                    ContactUS()
                }
            }
            Spacer(minLength: 0)

        }
        .edgesIgnoringSafeArea(.bottom)
        .preferredColorScheme(.dark)
        .onAppear{
            music.music.volume = volume
        }
    }
}

struct ProfileContentViewContainer: View{
    @State var index = ProfileContent.accountInfo
    @State var account = Account(Name: "NameTest", Image: AssetsExtractor.createLocalUrl(forImageNamed: "outline_account_circle_white_36pt")!, Email: "email.email", State: false, Content: "Log In")
    @State var musicPlayer = Music(music: AVQueuePlayer(), isPlaying: false, volume: Float(1))
    
    var body: some View{
        ProfileContentView(profileIndex: $index, account: $account, music: $musicPlayer)
    }
}

struct ProfileContentView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileContentViewContainer()
    }
}
