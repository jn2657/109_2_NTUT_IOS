//
//  ContentView.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/10.
//

import SwiftUI
import FacebookLogin
import AVFoundation

enum Tab{
    case main, rank, profile
}

struct Account {
    var Name: String
    var Image: URL
    var Email: String
    var State: Bool
    var Content: String
}

struct Music {
    var music: AVQueuePlayer
    var isPlaying: Bool
    var volume: Float?
}

struct ContentView: View {
    @State var tabIndex: Tab = .main
    @State var account = Account(Name: "None", Image: AssetsExtractor.createLocalUrl(forImageNamed: "outline_account_circle_white_36pt")!, Email: "email.com", State: false, Content: "Log In")
    @State var looper: AVPlayerLooper?
    @State var musicPlayer = Music(music: AVQueuePlayer(), isPlaying: false, volume: Float(0.3))

    var body: some View {
        NavigationView{
            VStack(spacing: 0) {
                ZStack {
                    if tabIndex == .main {
                        MainView()
                    }else if tabIndex == .rank {
                        RankingView()
                    }else if tabIndex == .profile {
                        Profile_View(account: $account, music: $musicPlayer)
                    }
                }
                Spacer(minLength: 0)
                MainTabView(tabIndex: self.$tabIndex, account: $account)

            }
            .edgesIgnoringSafeArea(.bottom)
            .preferredColorScheme(.dark)
            .onAppear{
                musicPlayer.music.volume = musicPlayer.volume!
                if(!musicPlayer.isPlaying){
                    let url = Bundle.main.url(forResource: "music", withExtension: "mp4")!
                    let item = AVPlayerItem(url: url)
                    self.looper = AVPlayerLooper(player: musicPlayer.music, templateItem: item)
                    musicPlayer.music.play()
                    musicPlayer.isPlaying = true
                }
            }
        }
        
    }
}

struct MainTabView: View{
    @Binding var tabIndex: Tab
    @Binding var account: Account
    
    func updateAccount(){
        let request = GraphRequest(graphPath: "me", parameters: ["fields": "id, email, name"])
        request.start { (response, result, error) in
           if let result = result as? [String:String] {
            account.Name = result["name"] ?? ""
            account.Email = result["email"] ?? ""
            if(account.Email != ""){
                account.State = true
                account.Content = "Log Out"
            }
           }
        }
    }
    
    var body: some View {
        HStack {
            Group {
                Spacer()

                Button (action: {
                    self.tabIndex = .main
                }) {
                    VStack {
                        Image("outline_games_white_36pt")
                        Text("遊戲")
                    }
                }
                Spacer(minLength: 0)
                Button (action: {
                    self.tabIndex = .rank
                }) {
                    VStack {
                        Image("outline_stacked_bar_chart_white_36pt")
                        Text("Rank")
                    }
                }
                Spacer(minLength: 0)
                Button (action: {
                    if(AccessToken.current != nil){
                    }
                    updateAccount()
                    self.tabIndex = .profile
                }) {
                    VStack {
                        Image("outline_manage_accounts_white_36pt")
                        Text("Profile")
                    }
                }

                Spacer()
            }
            .padding(.bottom, 15)
        }
        .font(.system(size: 20))
        .frame(height: 70)
        .background(Color.black.opacity(0.1))
    }
}

struct MainView: View {
    @State private var message = ""
    @State private var showLoginView = false
    var body: some View{
            ZStack{
                Color.black
                VStack{
                    HStack{
                        NavigationLink(destination: G1InstructionsView(playerName: ""), label: {
                            VStack{
                                Image(systemName: "rectangle.split.3x3")
                                    .font(.system(size: 60))
                                    .foregroundColor(.white)
                                    
                                Text("OneSecondMemory")
                                    .font(.custom("Bradley Hand", size: 18))
                                    .foregroundColor(.white)
                            }
                            .padding()
                        })
                        
                        NavigationLink(destination: G2InstructionsView(), label: {
                            VStack{
                                Image(systemName: "rectangle.split.3x3.fill")
                                    .font(.system(size: 60))
                                    .foregroundColor(.white)
                                    
                                Text("OneSecondMemory+")
                                    .font(.custom("Bradley Hand", size: 17))
                                    .foregroundColor(.white)
                            }
                            .padding()
                        })
                    }
                    
                    HStack{
                        NavigationLink(destination: G3InstructionsView(), label: {
                            VStack{
                                Image(systemName: "rectangle.fill.on.rectangle.angled.fill")
                                    .font(.system(size: 60))
                                    .foregroundColor(.white)
                                    
                                Text("FlipCards")
                                    .font(.custom("Bradley Hand", size: 18))
                                    .foregroundColor(.white)

                            }
                            .padding()
                        })
                        
                        HStack{Spacer()}
                            .frame(width: 60, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        
                        NavigationLink(destination: G4InstructionsView(), label: {
                            VStack{
                                ZStack(alignment: .bottomTrailing){
                                    Image(systemName: "circle")
                                        .font(.system(size: 60))
                                        .foregroundColor(.white)
                                    
                                    Image(systemName: "circle.fill")
                                        .font(.system(size: 40))
                                        .foregroundColor(.white)
                                }
                                    
                                Text("TrackingBalls")
                                    .font(.custom("Bradley Hand", size: 18))
                                    .foregroundColor(.white)

                            }
                            .padding()
                        })
                    }
                    
                    HStack{
                        NavigationLink(destination: G5InstructionsView(), label: {
                            VStack{
                                Image(systemName: "hare")
                                    .font(.system(size: 60))
                                    .foregroundColor(.white)
                                    
                                Text("CountTheNumber")
                                    .font(.custom("Bradley Hand", size: 18))
                                    .foregroundColor(.white)
                            }
                            .padding()
                        })
                        
                        NavigationLink(destination: G6InstructionsView(), label: {
                            VStack{
                                Image(systemName: "square.fill.and.line.vertical.and.square")
                                    .font(.system(size: 60))
                                    .foregroundColor(.white)
                                    
                                Text("FindTheDifferences")
                                    .font(.custom("Bradley Hand", size: 18))
                                    .foregroundColor(.white)
                            }
                            .padding()
                        })
                    }
                }
                    
                    NavigationLink(destination: RankingView(), label: {
                        HStack{
                            Image(systemName: "rosette")
                                .font(.system(size: 30))
                                .foregroundColor(.yellow)
                            
                            Text("Ranking")
                                .font(.custom("Bradley Hand", size: 25))
                                .foregroundColor(.yellow)
                        }.padding()
                        .overlay(
                            RoundedRectangle(cornerRadius: 40)
                                .stroke(Color.yellow, lineWidth: 5)
                        )
                    })
                    .padding()
                    .position(x: 200, y: 750)
            }
            .edgesIgnoringSafeArea(.all)
            .toolbar(content: {
                ToolbarItem(placement: .principal) {
                    VStack{
                        Text("Memorize.io")
                            .font(.custom("Chalkduster", size: 52))
                            .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
                    }
                }
            })
        }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().preferredColorScheme(.dark)
    }
}
