//
//  ContactUS.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import SwiftUI

struct ContactUS: View {
    var body: some View {
        VStack{
            Text("Contact Information：")
                .font(.custom("Bradley Hand", size: 35))
                .foregroundColor(.blue)
                .padding()
            
            Text("t107820004@ntut.org.tw")
                .font(.custom("Bradley Hand", size: 30))
                .padding()
            
            Text("t107820009@ntut.org.tw")
                .font(.custom("Bradley Hand", size: 30))
                .padding()
            
            Text("t107820017@ntut.org.tw")
                .font(.custom("Bradley Hand", size: 30))
                .padding()
        }
    }
}

struct ContactUS_Previews: PreviewProvider {
    static var previews: some View {
        ContactUS()
    }
}
