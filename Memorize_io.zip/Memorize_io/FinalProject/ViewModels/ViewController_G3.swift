//
//  ViewController.swift
//  LAB04-MatchingGmae
//
//  Created by 上官 on 2021/3/29.
//

import UIKit

var turn = 1

class ViewController_G3: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    lazy var game:MatchingGame = MatchingGame(numberOfPairsOfCards: (cardList.count+1)/2)
    
    var flipCount:Int = 0{
        didSet{
            counter.text = "Player1 : \(flipCount)"
        }
    }
    
    var scoreCount:Int = 0{
        didSet{
            score.text = "Palyer2 : \(scoreCount)"
        }
    }
        
    var emojis = ["👻","👾","☀️","🐾","🐙","🍭","🐳","🐷"]
    
    var emojiDict = [Card_Match:String]()
    
    func emoji(for card: Card_Match) -> String{
        if emojiDict[card] == nil, emojis.count>0{
            let randomIndex = Int(arc4random_uniform(UInt32(emojis.count)))
            emojiDict[card] = emojis.remove(at: randomIndex)
        }
        return emojiDict[card] ?? "?"
    }
    
//    func matched(){
//        scoreCount += 5
//    }

    @IBAction func touchcard(_ sender: UIButton) {
        var sc = 0
        if let cardNumber = cardList.firstIndex(of: sender){
            print("cardnumber = \(String(describing: cardNumber))")
             sc = game.chooseCard(at: cardNumber)
            updateViewFromModel()
        }else{
            print("not found")
        }
        if turn == 1 {
            flipCount += sc
        }else if turn == 2 {
            scoreCount += sc
        }
        if change {
            if turn == 1 {
                counter.textColor = UIColor.systemOrange
                score.textColor = UIColor.white
            }else if turn == 2 {
                counter.textColor = UIColor.white
                score.textColor = UIColor.systemOrange
            }
            change = false
        }
//        score.text = "SCOREs : \(scoreCount)"
    }
    
    func updateViewFromModel(){
        for index in cardList.indices{
            let button = cardList[index]
            let card = game.cards[index]
            if card.isFaceup && !card.isMatched{
                button.setTitle(emoji(for: card), for: UIControl.State.normal)
                button.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
//                scoreCount -= 1
            }else if card.isMatched{
                button.setTitle(emoji(for: card), for: UIControl.State.normal)
                button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.5)
//                scoreCount += 2.5
            }
            else{
                button.setTitle("", for: UIControl.State.normal)
                button.backgroundColor = #colorLiteral(red: 0.5807225108, green: 0.066734083, blue: 0, alpha: 1)
//                scoreCount -= 1
            }
        }
    }
    
    @IBOutlet weak var counter: UILabel!
    
    @IBOutlet var cardList: [UIButton]!
    
    @IBOutlet weak var score: UILabel!
    
    var check = false
    
    @IBAction func reset(_ sender: Any) {
        for i in 0...cardList.count-1{
            let button = cardList[i]
            button.backgroundColor = #colorLiteral(red: 0.5807225108, green: 0.066734083, blue: 0, alpha: 1)
            button.setTitle("",for:UIControl.State.normal)
        }
        game.flipallcarddown()
        flipCount = 0
        scoreCount = 0
        check = false
        turn = 1
    }
    
    @IBAction func flipall(_ sender: Any) {
        flipCount = 0
        scoreCount = 0
        if check{
            for i in 0...cardList.count-1{
                let button = cardList[i]
                button.backgroundColor = #colorLiteral(red: 0.5807225108, green: 0.066734083, blue: 0, alpha: 1)
                button.setTitle("",for:UIControl.State.normal)
            }
            game.flipallcarddown()
            check = false
        }else{
            for i in 0...cardList.count-1{
                let button = cardList[i]
                let card = game.cards[i]
                button.setTitle(emoji(for: card), for: UIControl.State.normal)
                button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.5)
            }
            game.flipallcardup()
            check = true
        }

    }

}

