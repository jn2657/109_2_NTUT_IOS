//
//  G1InstructionsView.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/10.
//

import SwiftUI

struct G1InstructionsView: View{
    func re(){ UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(red: 0.4, green: 0.7, blue: 1.0, alpha: 1.0), .font: UIFont(name: "Chalkduster", size: 30)!]
    }
    
    @State var playerName: String
    
    var body: some View {
        ZStack{
            Color.black
            VStack{
                Image(systemName: "rectangle.split.3x3")
                    .font(.system(size: 60))
                    .foregroundColor(.white)
                
                Text("遊戲方法 :")
                    .font(.custom("Bradley Hand", size: 25))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎隨機亮起九個方格")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎顯示一秒的時間")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎蓋上後,依記憶點選")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                TextField("Player1", text: $playerName)
                    .border(Color.gray, width: 3)
                    .font(.title)
                    .foregroundColor(.gray)
                    .cornerRadius(5)
                    .padding(.horizontal, 70)
                    .padding(.vertical, 30)
            }
                
            NavigationLink(
                destination: G1(),
                label: {
                    VStack{
                        Text("Good Luck!")
                            .font(.custom("Bradley Hand", size: 50))
                            .foregroundColor(.yellow)
                    
                        Image(systemName: "play.rectangle")
                            .font(.system(size: 60))
                            .foregroundColor(.yellow)
                    }
                })
                .position(x: 200, y: 750)
        }
        .navigationBarTitleDisplayMode(.inline)
        .edgesIgnoringSafeArea(.all)
        //.navigationTitle("OneSecondMemory")
        .toolbar(content: {
            ToolbarItem(placement: .principal) {
                VStack{
                    Text("OneSecondMemory")
                        .font(.custom("Chalkduster", size: 28))
                        .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
                }
            }
        })

//        .navigationBarTitleDisplayMode(.automatic)
        
//        .toolbar(content: {
//            ToolbarItem(placement: .principal) {
//                VStack{
//                    Text("One Second")
//                        .font(.custom("Chalkduster", size: 52))
//                        .foregroundColor(.white)
//                    Text("Memory")
//                        .font(.custom("Chalkduster", size: 52))
//                        .foregroundColor(.white)
//                    Text(".Normal")
//                        .font(.custom("Chalkduster", size: 52))
//                        .foregroundColor(.white)
//                }
//                .offset(y: 50.0)
//            }
//        })
    }
}

struct G1InstructionsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            G1InstructionsView(playerName: "Player1")
        }
    }
}
