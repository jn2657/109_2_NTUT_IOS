//
//  OneSecondMemory.swift
//  memorize2.io
//
//  Created by 李昆哲 on 2021/5/13.
//

import Foundation

class OneSecondMemory {
    var cards:[Card] = []
    
    func chooseCard(at index: Int) -> Bool{
        cards[index].isTouched = true
        if(cards[index].isActivate){
            return true
        }else{
            return false
        }
    }
    
    func reset(level: Int){
        for i in cards.indices{
            cards[i].isActivate = false
            cards[i].stopWork = false
            if(cards[i].hashValue <= level){
                cards[i].isActivate = true
            }else{
                cards[i].isActivate = false
            }
            cards[i].isTouched = false
        }
        cards.shuffle()        
    }
    
    init(totalCards: Int) {
        for _ in 0...totalCards-1{
            let card = Card()
            cards.append(card)
        }
        cards.shuffle()
    }
}
