//
//  ViewController.swift
//  game
//
//  Created by WUIJUI on 2021/6/6.
//

import UIKit
public var globalpoint:Int = 0

class ViewController_G4: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "main")!)
        globalpoint = 0
        points.text = "目前分數：\(globalpoint)"
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var points: UILabel!
    
    
}

