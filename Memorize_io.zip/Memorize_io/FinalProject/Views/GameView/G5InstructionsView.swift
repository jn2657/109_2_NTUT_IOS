//
//  G5InstructionsView.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/10.
//

import SwiftUI

struct G5InstructionsView: View{
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(red: 0.4, green: 0.7, blue: 1.0, alpha: 1.0), .font: UIFont(name: "Chalkduster", size: 30)!]
    }
    
    var body: some View {
        ZStack{
            Color.black
            VStack{
                Image(systemName: "hare")
                    .font(.system(size: 60))
                    .foregroundColor(.white)
                
                Text("遊戲方法：")
                    .font(.custom("Bradley Hand", size: 25))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎一段時間內")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎同時有兔子進入和離開")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎最後回答出正確兔子數量")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
            }
            
            NavigationLink(
                destination: G5(),
                label: {
                    VStack{
                        Text("Good Luck!")
                            .font(.custom("Bradley Hand", size: 50))
                            .foregroundColor(.yellow)
                    
                        Image(systemName: "play.rectangle")
                            .font(.system(size: 60))
                            .foregroundColor(.yellow)
                    }
                })
                .position(x: 200, y: 750)
        }
        .navigationBarTitleDisplayMode(.inline)
        .edgesIgnoringSafeArea(.all)
        //.navigationTitle("CountTheNumber")
        .toolbar(content: {
        ToolbarItem(placement: .principal) {
            VStack{
                Text("CountTheNumber")
                    .font(.custom("Chalkduster", size: 28))
                    .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
            }
        }
    })
    }
}

struct G5InstructionsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            G5InstructionsView()
        }
    }
}
