//
//  RankingView.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/10.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct RankingView: View{
    @State var ranks = [Rank]()
    @State var gameIndex = 0
    @State var game = "OneSecondMemory"
    let games = ["OneSecondMemory", "OneSecondMemory+"]
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.yellow, .font: UIFont(name: "Chalkduster", size: 30)!]

        UITableView.appearance().backgroundColor = .clear
        UITableViewCell.appearance().backgroundColor = .clear
    }
    
    func fetchRanks(){
        let db = Firestore.firestore()
        db.collection("\(game)")
            .order(by: "score", descending: true)
            .limit(to: 5)
            .getDocuments{snapshot, error in
            guard let snapshot = snapshot else{return}
            ranks = snapshot.documents.compactMap{
                snapshot in
                try? snapshot.data(as: Rank.self)
            }
        }
    }
    
    func changeGameRight(){
        if(gameIndex < games.count-1){
            gameIndex += 1
            game = games[gameIndex]
            fetchRanks()
        }
    }
    
    func changeGameLeft(){
        if(gameIndex > 0){
            gameIndex -= 1
            game = games[gameIndex]
            fetchRanks()
        }
    }
    
    var body: some View {
            ZStack{
                Color.black
                VStack{
                    List(ranks) { rank in
                        RankRow(player: rank)
                            .listRowBackground(Color(.black))
                    }
                    .listRowBackground(Color(.black))
                    Text("\(game)")
                        .font(.custom("Bradley Hand", size: 30))
                        .foregroundColor(.white)
                    HStack{
                        Button(action: {changeGameLeft()}, label: {
                            Image(systemName: "arrow.left.circle")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                        })
                        .padding(.trailing, 100)
                        .padding(.top, 50)
                        Button(action: {changeGameRight()}, label: {
                            Image(systemName: "arrow.right.circle")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                        })
                        .padding(.top, 50)
                    }
                    .padding(.bottom, 100)
                }
            }
            .edgesIgnoringSafeArea(.all)
            //.navigationTitle("Ranking")
            .onAppear(perform: {
                fetchRanks()
            })
            .toolbar(content: {
                ToolbarItem(placement: .principal) {
                    VStack{
                        Text("Ranking")
                            .font(.custom("Chalkduster", size: 52))
                            .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
                    }
                }
            })
        }
}

struct Rank: Codable, Identifiable{
    @DocumentID var id: String?
    let name: String
    let score: Int
}


struct RankingView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            RankingView()
        }
    }
}
