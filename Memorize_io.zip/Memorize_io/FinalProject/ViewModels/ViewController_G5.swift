//
//  ViewController.swift
//  game2
//
//  Created by WUIJUI on 2021/6/20.
//

import UIKit

class ViewController_G5: UIViewController {
    var globalpoint:Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        globalpoint = 0
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "main")!)
        // Do any additional setup after loading the view.
    }


}

