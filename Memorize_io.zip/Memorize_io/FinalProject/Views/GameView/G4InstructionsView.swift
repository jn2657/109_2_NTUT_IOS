//
//  G4InstructionsView.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/10.
//

import SwiftUI

struct G4InstructionsView: View{
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(red: 0.4, green: 0.7, blue: 1.0, alpha: 1.0), .font: UIFont(name: "Chalkduster", size: 30)!]
    }
    
    var body: some View {
        ZStack{
            Color.black
            VStack{
                ZStack(alignment: .bottomTrailing){
                    Image(systemName: "circle")
                        .font(.system(size: 60))
                        .foregroundColor(.white)
                    
                    Image(systemName: "circle.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                }
                
                Text("遊戲方法：")
                    .font(.custom("Bradley Hand", size: 25))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎鎖定其中一顆球")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎所有求隨機移動一段距離後停下")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎選出剛剛鎖定的那顆球")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎鎖定之球的數量會越來越多")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
            }
            
            NavigationLink(
                destination: G4(),
                label: {
                    VStack{
                        Text("Good Luck!")
                            .font(.custom("Bradley Hand", size: 50))
                            .foregroundColor(.yellow)
                    
                        Image(systemName: "play.rectangle")
                            .font(.system(size: 60))
                            .foregroundColor(.yellow)
                    }
                })
                .position(x: 200, y: 750)
                
        }
        .navigationBarTitleDisplayMode(.inline)
        .edgesIgnoringSafeArea(.all)
        //.navigationTitle("TrackingBalls")
        .toolbar(content: {
            ToolbarItem(placement: .principal) {
                VStack{
                    Text("TrackingBalls")
                        .font(.custom("Chalkduster", size: 28))
                        .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
                }
            }
        })
    }
}

struct G4InstructionsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            G4InstructionsView()
        }
    }
}
