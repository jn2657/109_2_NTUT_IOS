//
//  G4.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import Foundation
import SwiftUI

struct G4: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> ViewController_G4 {
            UIStoryboard(name: "G4", bundle: nil).instantiateViewController(identifier: "ViewController_G4") as! ViewController_G4
        }
        
    func updateUIViewController(_ uiViewController: ViewController_G4, context: Context) {
    }
    typealias UIViewType = ViewController_G4
}

struct G4_Previews: PreviewProvider {
    static var previews: some View {
        G4().preferredColorScheme(.dark)
    }
}
