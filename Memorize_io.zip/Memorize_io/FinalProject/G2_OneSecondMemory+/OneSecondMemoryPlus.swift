//
//  OneSecondMemory+.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/16.
//

import Foundation
class OneSecondMemoryPlus {
    var cards:[Card] = []
    var activateAmount = 0
    var touchOrder = 1
    
    func chooseCard(at index: Int) -> Bool{
        cards[index].isTouched = true
        if(cards[index].hashValue == touchOrder && cards[index].isActivate){
            touchOrder += 1
            return true
        }else{
            return false
        }
    }
    
    func reset(level: Int){
        for i in cards.indices{
            cards[i].isActivate = false
            cards[i].stopWork = false
            if(cards[i].hashValue <= level){
                cards[i].isActivate = true
            }else{
                cards[i].isActivate = false
            }
            cards[i].isTouched = false
        }
        touchOrder = 1
        cards.shuffle()
    }
    
    init(totalCards: Int) {
        for _ in 0...totalCards-1{
            let card = Card()
            cards.append(card)
        }
        cards.shuffle()
    }
}
