//
//  G3InstructionsView.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/10.
//

import SwiftUI

struct G3InstructionsView: View{
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(red: 0.4, green: 0.7, blue: 1.0, alpha: 1.0), .font: UIFont(name: "Chalkduster", size: 30)!]
    }
    
    var body: some View {
        ZStack{
            Color.black
            VStack{
                Image(systemName: "rectangle.fill.on.rectangle.angled.fill")
                    .font(.system(size: 60))
                    .foregroundColor(.white)
                
                Text("遊戲方法：")
                    .font(.custom("Bradley Hand", size: 25))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◉雙人小遊戲")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎翻開兩張牌")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎成功配對則繼續")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎未配對成功則換人")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
            }
                
            NavigationLink(
                destination: G3(),
                label: {
                    VStack{
                        Text("Good Luck!")
                            .font(.custom("Bradley Hand", size: 50))
                            .foregroundColor(.yellow)
                    
                        Image(systemName: "play.rectangle")
                            .font(.system(size: 60))
                            .foregroundColor(.yellow)
                    }
                })
                .position(x: 200, y: 750)
        }
        .navigationBarTitleDisplayMode(.inline)
        .edgesIgnoringSafeArea(.all)
        //.navigationTitle("FlipCards")
        .toolbar(content: {
            ToolbarItem(placement: .principal) {
                VStack{
                    Text("FlipCards")
                        .font(.custom("Chalkduster", size: 28))
                        .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
                }
            }
        })
    }
}

struct G3InstructionsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            G3InstructionsView()
        }
    }
}

