//
//  LoginView.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/1.
//

import SwiftUI
import FacebookLogin

struct LoginView: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var account: Account
    @State var playerName = ""
    @State private var FBSignInContent = "Sign in with Facebook"

    var body: some View {
        ZStack {
            Color.black
            VStack {
                HStack{
                    Text("Player Name:")
                        .font(.custom("Bradley Hand", size: 30))
                        .foregroundColor(.white)
                    
                    TextField("", text: $playerName)
                        .padding()
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.white, lineWidth: 5)
                        )
                }.padding()
                
                Button(action: {
                    //account.setName(name: playerName)
                    account.Name = playerName
                    presentationMode.wrappedValue.dismiss()
                }, label: {
                    HStack{
                        Image(systemName: "person.crop.circle.badge.plus")
                            .font(.system(size: 25))
                        Text("Sign in")
                            .font(.system(size: 25))
                    }
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .padding()
                    .foregroundColor(.black)
                    .background(Color.white)
                    .cornerRadius(40)
                })
                .padding()
                
                Text("or")
                    .font(.custom("Bradley Hand", size: 30))
                    .foregroundColor(.white)
                Button(action: {
                    let manager = LoginManager()
                    if(AccessToken.current == nil){
                        manager.logIn(permissions: [ .publicProfile,.email ]) { (result) in
                            if case LoginResult.success(granted: _, declined: _, token: _) = result {
                                if AccessToken.current != nil {
                                    Profile.loadCurrentProfile { (profile, error) in
                                        if let profile = profile {
                                            account.Name = profile.name ?? ""
                                            account.Image = profile.imageURL(forMode: .square, size: CGSize(width: 300, height: 300))
                                                ?? AssetsExtractor.createLocalUrl(forImageNamed: "outline_account_circle_white_36pt")!
                                            account.Email = profile.email ?? ""
                                            account.State = true
                                            account.Content = "Log Out"
                                            FBSignInContent = "\(account.Name) Sign Out"
                                        }
                                    }
                                }
                            } else {
                                print("login fail")
                            }
                        }
                    }else{
                        manager.logOut()
                        account.State = true
                        account.Content = "Log In"
                        FBSignInContent = "Sign in with Facebook"
                    }
                }) {
                    HStack {
                        Image("outline_facebook_white_36pt")
                            .font(.title)
                        Text(FBSignInContent)
                            .fontWeight(.semibold)
                            .font(.title2)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(40)
                    .padding(.horizontal, 20)
                }
                Button(action: {
                    
                    
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                            .font(.title)
                        Text("Sign in with Google")
                            .fontWeight(.semibold)
                            .font(.title2)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.red)
                    .cornerRadius(40)
                    .padding(.horizontal, 20)
                }
                Button(action: {
                    
                    
                }) {
                    HStack {
                        Image(systemName: "applelogo")
                            .font(.title)
                        Text("Sign in with Apple")
                            .fontWeight(.semibold)
                            .font(.title2)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .padding()
                    .foregroundColor(.black)
                    .background(Color.white)
                    .cornerRadius(40)
//                    .overlay(
//                            RoundedRectangle(cornerRadius: 40)
//                                .stroke(Color.black, lineWidth: 5)
//                        )
                    .padding(.horizontal, 20)
                }
            }
        }
    }
}

//struct LoginView_Previews: PreviewProvider {
//    static var previews: some View {
//        LoginView()
//    }
//}


