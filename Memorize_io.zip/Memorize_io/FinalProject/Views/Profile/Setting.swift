//
//  Setting.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/21.
//

import SwiftUI
import AVFoundation

struct Setting: View {
    @Binding var volume: Float
    
    var body: some View {
        VStack {
            HStack {
                Text("BGM")
                    .font(.title)
                    .padding()
                ZStack {
                    Slider(value: $volume, in: 0...1)
                }
                .padding()
                .onAppear{
                }
            }
            HStack{
                Text("On/Off")
                    .font(.title)
                    .padding()
                Toggle(isOn: /*@START_MENU_TOKEN@*/.constant(true)/*@END_MENU_TOKEN@*/, label: {
                    
                })
                .padding()
            }
        }
    }
}

struct SettingContainer: View{
    @State var volume = Float(1)
    
    var body: some View{
        Setting(volume: $volume)
    }
}

struct Setting_Previews: PreviewProvider {
    static var previews: some View {
        SettingContainer()
    }
}
