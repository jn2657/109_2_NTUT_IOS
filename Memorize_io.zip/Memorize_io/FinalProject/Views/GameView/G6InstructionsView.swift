//
//  G6InstructionsView.swift
//  FinalProject
//
//  Created by 上官 on 2021/5/10.
//

import SwiftUI

struct G6InstructionsView: View{
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(red: 0.4, green: 0.7, blue: 1.0, alpha: 1.0), .font: UIFont(name: "Chalkduster", size: 30)!]
    }
    
    var body: some View {
        ZStack{
            Color.black
            VStack{
                Image(systemName: "square.fill.and.line.vertical.and.square")
                    .font(.system(size: 60))
                    .foregroundColor(.white)
                
                Text("遊戲方法：")
                    .font(.custom("Bradley Hand", size: 25))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎暫時顯示圖片原圖")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎之後顯示不同於原圖的圖片")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
                
                Text("◎找出與原圖不同之處")
                    .font(.custom("Bradley Hand", size: 20))
                    .foregroundColor(.white)
                    .padding()
            }
            
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                VStack{
                    Text("Good Luck!")
                        .font(.custom("Bradley Hand", size: 50))
                        .foregroundColor(.yellow)
                
                    Image(systemName: "play.rectangle")
                        .font(.system(size: 60))
                        .foregroundColor(.yellow)
                }
            })
            .position(x: 200, y: 750)
        }
        .edgesIgnoringSafeArea(.all)
        //.navigationTitle("FindTheDifferences")
        .toolbar(content: {
            ToolbarItem(placement: .principal) {
                VStack{
                    Text("FindTheDifferences")
                        .font(.custom("Chalkduster", size: 28))
                        .foregroundColor(Color(red: 0.4, green: 0.7, blue: 1.0, opacity: 1.0))
                }
            }
        })
    }
}

struct G6InstructionsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            G6InstructionsView()
        }
    }
}
