//
//  G3.swift
//  FinalProject
//
//  Created by 李昆哲 on 2021/6/23.
//

import Foundation
import SwiftUI

struct G3: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> ViewController_G3 {
            UIStoryboard(name: "G3", bundle: nil).instantiateViewController(identifier: "ViewController_G3") as! ViewController_G3
        }
        
    func updateUIViewController(_ uiViewController: ViewController_G3, context: Context) {
    }
    typealias UIViewType = ViewController_G3
}

struct G3_Previews: PreviewProvider {
    static var previews: some View {
        G3().preferredColorScheme(.dark)
    }
}
