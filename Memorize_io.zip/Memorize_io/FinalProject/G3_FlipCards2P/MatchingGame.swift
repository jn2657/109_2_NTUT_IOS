//
//  MatchingGmae.swift
//  LAB04-MatchingGmae
//
//  Created by 上官 on 2021/3/29.
//

import Foundation

var change = false

var justMatched = false

class MatchingGame{
    var cards:[Card_Match] = []
    
    var indexOfOneAndOnlyFaceUpCard: Int?
//    {
//        get{
//            var foundIndex:Int?
//            for index in cards.indices{
//                if cards[index].isFaceup{
//                    if foundIndex == nil{
//                        foundIndex = index
//                    }else{
//                        return nil
//                    }
//                }
//            }
//            return foundIndex
//        }set{
//            for index in cards.indices{
//                cards[index].isFaceup = (foundindex == newValue)
//            }
//        }
//    }
    
    func chooseCard(at index: Int)->Int{
//        if cards[index].isFaceup{
//            cards[index].isFaceup = false
//        }else{
//            cards[index].isFaceup = true
//        }
        var count = 0
        if !cards[index].isMatched{
            if let matchIndex = indexOfOneAndOnlyFaceUpCard, matchIndex != index{
                if cards[matchIndex] == cards[index]{
                    cards[matchIndex].isMatched = true
                    cards[index].isMatched = true
                    count = 5
                    justMatched = true
                }
                cards[index].isFaceup = true
                indexOfOneAndOnlyFaceUpCard = nil
//                justMatched = false
//                return 5
//                scoreCount += 5
                if !justMatched {
                    if turn == 1{
                        turn = 2
                    }else {
                        turn = 1
                    }
                    change = true
                }else {
                    justMatched = false
                }
            }//has another previous card face up
            else{//no cards face up or 2 cards have faced up
                for flipDownIndex in cards.indices{
                    cards[flipDownIndex].isFaceup = false
                }
                cards[index].isFaceup = true
                indexOfOneAndOnlyFaceUpCard = index
//                return 0
            }
        }
        return count
    }
    
    func flipallcarddown(){
        for i in 0...cards.count-1{
            cards[i].isFaceup = false
            cards[i].isMatched = false
        }
        cards.shuffle()
    }
    
    func flipallcardup(){
        for i in 0...cards.count-1{
            cards[i].isFaceup = true
            cards[i].isMatched = true
        }
    }
    
    init(numberOfPairsOfCards: Int){
        for _ in 0...numberOfPairsOfCards-1{
            let card = Card_Match()
            cards += [card, card]
        }
        cards.shuffle()
    }
}
