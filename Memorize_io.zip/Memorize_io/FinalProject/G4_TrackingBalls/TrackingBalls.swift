//
//  game.swift
//  game
//
//  Created by WUIJUI on 2021/6/6.
//

import UIKit

class TrackingBalls {
    public var Balls:[ball] = []

    func choose(at index:Int) -> Bool{
        if Balls[index].isAnswer {
            return true
        }
        else{
            return false
        }
    }
    
    init(level:Int) {
        for _ in 0...level + 5 {
            //var temp = ball()
            Balls.append(ball())
        }
        if level < 2 {
            Balls[0].isAnswer = true
            Balls[1].isAnswer = true
        }
        else if level < 3{
            Balls[0].isAnswer = true
            Balls[1].isAnswer = true
            Balls[2].isAnswer = true
        }
        else if level < 5{
            Balls[0].isAnswer = true
            Balls[1].isAnswer = true
            Balls[2].isAnswer = true
            Balls[3].isAnswer = true
        }
        else{
            Balls[0].isAnswer = true
            Balls[1].isAnswer = true
            Balls[2].isAnswer = true
            Balls[3].isAnswer = true
            Balls[4].isAnswer = true
        }
        
    }
}
